# -*- coding: utf-8 -*-
from odoo import http

# class MaintenanceRequestInstruction(http.Controller):
#     @http.route('/maintenance_request_instruction/maintenance_request_instruction/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/maintenance_request_instruction/maintenance_request_instruction/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('maintenance_request_instruction.listing', {
#             'root': '/maintenance_request_instruction/maintenance_request_instruction',
#             'objects': http.request.env['maintenance_request_instruction.maintenance_request_instruction'].search([]),
#         })

#     @http.route('/maintenance_request_instruction/maintenance_request_instruction/objects/<model("maintenance_request_instruction.maintenance_request_instruction"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('maintenance_request_instruction.object', {
#             'object': obj
#         })