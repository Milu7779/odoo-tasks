from odoo import api, fields, models

class MaintenanceRequest(models.Model):
    _inherit = 'maintenance.request'

    instruction_type = fields.Selection(
        [('pdf', 'pdf'),
         ('google_slide','google slide'),
         ('text','text')
         ],
        string='instruction Type',
        default="text")
    instruction_pdf = fields.Binary('PDF')
    instruction_google_slide = fields.Char(
        'Google Slide',
        help="Paste the url of your Google Slide. Make sure the access to the document is public.")
    instruction_text = fields.Text('Text')
    recurring_maintenance = fields.Boolean(
        string="Recurrent",
        compute='_compute_recurring_maintenance',
        store=True,
        readonly=False)

    repeat_interval = fields.Integer(
        string='Repeat Every',
        default=1)
    repeat_unit = fields.Selection([
        ('day', 'Days'),
        ('week', 'Weeks'),
        ('month', 'Months'),
        ('year', 'Years'),
    ], default='week')
    repeat_type = fields.Selection([
        ('forever', 'Forever'),
        ('until', 'Until'),
    ],
        default="forever",
        string="Until")
    repeat_until = fields.Date(string="End Date")

    @api.depends('maintenance_type')
    def _compute_recurring_maintenance(self):
        for request in self:
            if request.maintenance_type != 'preventive':
                request.recurring_maintenance = False